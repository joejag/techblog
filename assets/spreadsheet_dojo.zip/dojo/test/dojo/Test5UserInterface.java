package dojo;

/*
 +--------+---------------+------+
 | Label  |  Text entry   |  OK  |
 +--------+---------------+------+
 |                              ^|
 |        Grid (JTable)         ||
 |                              v|
 +-------------------------------+
 */
public class Test5UserInterface
{

}
